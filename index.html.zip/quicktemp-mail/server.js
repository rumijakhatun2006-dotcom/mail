const express=require('express');
const path=require('path');
const app=express();
const PORT=process.env.PORT||3000;
const API='https://www.1secmail.com/api/v1/';
app.use(express.json());
app.use(express.static(path.join(__dirname,'public')));
function randomLogin(){const chars='abcdefghijklmnopqrstuvwxyz0123456789';let s='';for(let i=0;i<10;i++)s+=chars[Math.floor(Math.random()*chars.length)];return s;}
app.get('/api/new-mail',(req,res)=>{const login=randomLogin();res.json({login,domain:'1secmail.com',email:`${login}@1secmail.com`});});
async function api(params){const r=await fetch(API+'?'+new URLSearchParams(params));if(!r.ok)throw new Error('Provider error');return r.json();}
app.get('/api/messages',async(req,res)=>{try{const {login,domain}=req.query;if(!login||!domain)return res.status(400).json({error:'Missing mailbox'});res.json(await api({action:'getMessages',login,domain}));}catch(e){res.status(502).json({error:'Mail provider unavailable'});}});
app.get('/api/message',async(req,res)=>{try{const {login,domain,id}=req.query;if(!login||!domain||!id)return res.status(400).json({error:'Missing message data'});res.json(await api({action:'readMessage',login,domain,id}));}catch(e){res.status(502).json({error:'Could not read message'});}});
app.get('*',(req,res)=>res.sendFile(path.join(__dirname,'public','index.html')));
app.listen(PORT,()=>console.log(`QuickTemp Mail: http://127.0.0.1:${PORT}`));
