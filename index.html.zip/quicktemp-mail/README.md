# QuickTemp Mail — Android setup

This demo uses the public 1secmail API for receiving temporary mail. Provider availability, limits and terms can change; this is not a private or permanent mailbox service.

## Termux
1. Install Node.js in Termux: `pkg update && pkg install nodejs`
2. Put this project folder in your Termux home directory.
3. Run: `cd quicktemp-mail && npm install && npm start`
4. Open Chrome and visit `http://127.0.0.1:3000`

## Files
- `server.js` — Express backend/proxy
- `public/index.html` — UI
- `public/style.css` — styling
- `public/app.js` — frontend logic
- `package.json` — dependency/start command

Use only for legitimate testing/privacy-friendly purposes. Do not use it for fraud, spam, account takeover, or bypassing security controls.
